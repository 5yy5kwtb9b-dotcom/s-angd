int demo_value(int n) { return n + 1; }
int main(void) { return demo_value(0); }
