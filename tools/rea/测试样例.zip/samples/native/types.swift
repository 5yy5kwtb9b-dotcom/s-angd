import Foundation
@objc protocol DemoViewing { func refresh() }
@objc(DemoViewController) final class DemoViewController:NSObject, DemoViewing {
 @objc func refresh() { print("demo") }
}
final class AccountSample { func label() -> String { "Account" } }
print(AccountSample().label())
DemoViewController().refresh()
