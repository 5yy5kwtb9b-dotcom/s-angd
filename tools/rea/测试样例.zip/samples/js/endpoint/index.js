export function reportLabel() { return {kind:'status', title:'ready'}; }
export function readReport() { return fetch('/demo/report'); }
