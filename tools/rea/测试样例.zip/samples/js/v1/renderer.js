import {getProfile} from './profile.js'; export function render(){ return getProfile(); }
