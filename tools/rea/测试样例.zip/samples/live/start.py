"""Run one disposable local target. The single stdout JSON line identifies it."""
import argparse
import http.server
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import tempfile
import threading
import time
import urllib.request

HERE = Path(__file__).resolve().parent
PAGE = HERE / 'page.html'
NODE = HERE.parent / 'node' / 'idle.cjs'

class PageHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path != '/fixture':
            self.send_error(404)
            return
        data = PAGE.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=UTF-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    def log_message(self, *args):
        pass

def run(mode, work, stop):
    profile = work / 'profile'
    log = work / 'host.log'
    server = None
    process = None
    origin = None
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        if mode == 'node':
            url = NODE.as_uri()
            command = ['node', '--inspect=127.0.0.1:0', str(NODE)]
        else:
            profile.mkdir()
            if mode == 'browser':
                server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), PageHandler)
                threading.Thread(target=server.serve_forever, daemon=True).start()
                origin = 'http://127.0.0.1:' + str(server.server_port)
                url = origin + '/fixture'
                command = [os.environ.get('CHROME_BIN', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'),
                           '--headless=new', '--no-first-run', '--disable-sync', '--disable-extensions']
                target = url
            else:
                url = PAGE.as_uri()
                command = [os.environ.get('ELECTRON_BIN') or shutil.which('electron') or '/Applications/Electron.app/Contents/MacOS/Electron']
                target = str(HERE / 'electron')
            command += ['--disable-background-networking', '--disable-component-update', '--disable-gpu',
                        '--proxy-server=http://127.0.0.1:9', '--proxy-bypass-list=127.0.0.1;localhost',
                        '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0',
                        '--user-data-dir=' + str(profile), target]
        with log.open('w') as stream:
            process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stream, stderr=stream, start_new_session=True)
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline and not stop.is_set():
            if process.poll() is not None:
                raise RuntimeError('测试进程已退出，状态码 ' + str(process.returncode))
            try:
                if mode == 'node':
                    ports = re.findall(r'ws://127\.0\.0\.1:(\d+)/', log.read_text(errors='replace'))
                    port = int(ports[0])
                else:
                    port = int((profile / 'DevToolsActivePort').read_text().splitlines()[0])
                endpoint = f'http://127.0.0.1:{port}'
                with opener.open(endpoint + '/json/list', timeout=1) as response:
                    targets = json.load(response)
                item = next(t for t in targets if t.get('type') == ('node' if mode == 'node' else 'page')
                            and urllib.parse.unquote(t.get('url','')) == urllib.parse.unquote(url))
                info = {'target_id': item['id']}
                if mode == 'node':
                    info.update(inspector_endpoint=endpoint, runtime_kind='node')
                else:
                    info['cdp_endpoint'] = endpoint
                    if origin:
                        info['allowed_origins'] = [origin]
                print(json.dumps(info), flush=True)
                stop.wait(600)
                return
            except (OSError, ValueError, IndexError, StopIteration):
                stop.wait(.15)
        if not stop.is_set():
            raise RuntimeError('30 秒内未找到本次启动的测试目标')
    finally:
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        if server is not None:
            server.shutdown()
            server.server_close()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['browser', 'electron', 'node'])
    mode = parser.parse_args().mode
    stop = threading.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda *_: stop.set())
    with tempfile.TemporaryDirectory(prefix='rea-local-') as directory:
        run(mode, Path(directory), stop)
