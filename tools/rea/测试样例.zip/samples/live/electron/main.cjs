const { app, BrowserWindow } = require('electron');
const path = require('node:path');
let window;
app.whenReady().then(() => {
  window = new BrowserWindow({ show: false, webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true } });
  window.loadFile(path.join(__dirname, '..', 'page.html'));
});
