.class public Ldemo/fixture/MainActivity;
.super Landroid/app/Activity;
.field public static final demo:I = 1
.method public constructor <init>()V
    .locals 0
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V
    return-void
.end method
